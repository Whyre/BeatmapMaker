package beatmap;

import javafx.beans.property.*;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Comparator;

/**
 * Created by William on 11/19/2015.
 */
public class HitObject implements Comparable<HitObject> {
    private IntegerProperty hitObject;
    private DoubleProperty beat;
    private StringProperty time;
    private StringProperty key;
    private DoubleProperty hitDuration;

    public HitObject(int hitObject, double beat, String time, String key, double hitDuration) {
        this.hitObject = new SimpleIntegerProperty(hitObject);
        this.beat = new SimpleDoubleProperty(beat);
        this.time = new SimpleStringProperty(time);
        this.key = new SimpleStringProperty(key);
        this.hitDuration = new SimpleDoubleProperty(hitDuration);
    }

    public void setHitObject(int value) {
        hitObjectProperty().setValue(value);
    }

    public int getHitObject() {
        return hitObjectProperty().get();
    }

    public IntegerProperty hitObjectProperty() {
        //if (hitObject == null) hitObject = new SimpleIntegerProperty(this, "hitObject");
        return hitObject;
    }

    public void setBeat(double value) {
        beatProperty().setValue(value);
    }

    public double getBeat() {
        return beatProperty().get();
    }

    public DoubleProperty beatProperty() {
        //if (beat == null) beat = new SimpleDoubleProperty(this, "beat");
        return beat;
    }

    public void setTime(String value) {
        timeProperty().setValue(value);
    }

    public String getTime() {
        return timeProperty().get();
    }

    public StringProperty timeProperty() {
        //if (time == null) time = new SimpleStringProperty(this, "--:--");
        return time;
    }

    public void setKey(String value) {
        keyProperty().setValue(value);
    }

    public String getKey() {
        return keyProperty().get();
    }

    public StringProperty keyProperty() {
        //if (key == null) key = new SimpleStringProperty(this, "key");
        return key;
    }

    public void setHitDuration(double value) {
        hitDurationProperty().setValue(value);
    }

    public double getHitDuration() {
        return hitDurationProperty().get();
    }

    public DoubleProperty hitDurationProperty() {
        //if (hitDuration == null) hitDuration = new SimpleDoubleProperty(this, "hitObjectDuration");
        return hitDuration;
    }


    @Override
    public int compareTo(HitObject ho) {
        if (this.getTime().equals(ho.getTime()))
            return 0;
        else if (this.getBeat() < ho.getBeat())
            return -1;
        else return 1;
    }

    public static double round(double value, int places) {
        if (places < 0) throw new IllegalArgumentException();

        BigDecimal bd = new BigDecimal(value);
        bd = bd.setScale(places, RoundingMode.HALF_UP);
        return bd.doubleValue();
    }
}
